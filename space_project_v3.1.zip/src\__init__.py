"""
Hybrid AI Trajectory Planning
============================
ML-based trajectory generation with optimization refinement.
"""

__version__ = "2.0.0"
